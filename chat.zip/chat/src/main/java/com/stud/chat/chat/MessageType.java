package com.stud.chat.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}